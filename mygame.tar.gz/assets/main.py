
import pygame
import random

# Initialize Pygame
pygame.init()

# Screen dimensions
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 400

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
GREY = (100, 100, 100)

# Game constants
GROUND_HEIGHT = 50
PLAYER_WIDTH = 20
PLAYER_HEIGHT = 40
PLAYER_X = 80

GRAVITY = 0.8
JUMP_STRENGTH = -15

OBSTACLE_MIN_WIDTH = 20
OBSTACLE_MAX_WIDTH = 50
OBSTACLE_MIN_HEIGHT = 30
OBSTACLE_MAX_HEIGHT = 80
OBSTACLE_START_X = SCREEN_WIDTH + 50

INITIAL_GAME_SPEED = 5
GAME_SPEED_INCREMENT = 0.005

OBSTACLE_SPAWN_INTERVAL = 1500
MIN_OBSTACLE_SPAWN_INTERVAL = 700

SCORE_INCREMENT_PER_FRAME = 0.1

# Set up display
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Pixel Leaper")

# Clock
clock = pygame.time.Clock()

# Fonts
font = pygame.font.Font(None, 36)
game_over_font = pygame.font.Font(None, 64)


# Obstacle class
class Obstacle:
    def __init__(self, x, y, width, height, speed):
        self.rect = pygame.Rect(x, y, width, height)
        self.speed = speed

    def update(self):
        self.rect.x -= self.speed

    def draw(self, screen):
        pygame.draw.rect(screen, BLUE, self.rect)


# Reset game function
def reset_game():
    global player_y
    global player_y_velocity
    global is_grounded
    global obstacles
    global score
    global game_active
    global game_speed
    global last_obstacle_spawn_time

    player_y = SCREEN_HEIGHT - GROUND_HEIGHT - PLAYER_HEIGHT
    player_y_velocity = 0
    is_grounded = True
    obstacles = []
    score = 0
    game_active = True
    game_speed = INITIAL_GAME_SPEED
    last_obstacle_spawn_time = pygame.time.get_ticks()


# Initial game state
player_y = SCREEN_HEIGHT - GROUND_HEIGHT - PLAYER_HEIGHT
player_y_velocity = 0
is_grounded = True

obstacles = []

score = 0

game_active = True

game_speed = INITIAL_GAME_SPEED

last_obstacle_spawn_time = pygame.time.get_ticks()


# Main game loop
running = True

while running:

    # Events
    for event in pygame.event.get():

        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:

            if event.key == pygame.K_SPACE:

                if game_active:

                    if is_grounded:
                        player_y_velocity = JUMP_STRENGTH
                        is_grounded = False

                else:
                    reset_game()

    # Game updates
    if game_active:

        # Gravity
        player_y_velocity += GRAVITY
        player_y += player_y_velocity

        # Ground collision
        if player_y >= SCREEN_HEIGHT - GROUND_HEIGHT - PLAYER_HEIGHT:
            player_y = SCREEN_HEIGHT - GROUND_HEIGHT - PLAYER_HEIGHT
            player_y_velocity = 0
            is_grounded = True

        # Increase difficulty
        game_speed += GAME_SPEED_INCREMENT
        score += SCORE_INCREMENT_PER_FRAME

        # Spawn obstacles
        current_time = pygame.time.get_ticks()

        current_spawn_interval = max(
            MIN_OBSTACLE_SPAWN_INTERVAL,
            OBSTACLE_SPAWN_INTERVAL - (int(score) // 100) * 50
        )

        if current_time - last_obstacle_spawn_time > current_spawn_interval:

            obstacle_width = random.randint(
                OBSTACLE_MIN_WIDTH,
                OBSTACLE_MAX_WIDTH
            )

            obstacle_height = random.randint(
                OBSTACLE_MIN_HEIGHT,
                OBSTACLE_MAX_HEIGHT
            )

            obstacle_y = (
                SCREEN_HEIGHT
                - GROUND_HEIGHT
                - obstacle_height
            )

            new_obstacle = Obstacle(
                OBSTACLE_START_X,
                obstacle_y,
                obstacle_width,
                obstacle_height,
                game_speed
            )

            obstacles.append(new_obstacle)

            last_obstacle_spawn_time = current_time

        # Update obstacles
        for obstacle in list(obstacles):

            obstacle.update()

            if obstacle.rect.right < 0:
                obstacles.remove(obstacle)

        # Collision detection
        player_rect = pygame.Rect(
            PLAYER_X,
            player_y,
            PLAYER_WIDTH,
            PLAYER_HEIGHT
        )

        for obstacle in obstacles:

            if player_rect.colliderect(obstacle.rect):
                game_active = False

        # Draw background
        screen.fill(WHITE)

        # Draw ground
        pygame.draw.rect(
            screen,
            GREY,
            (0, SCREEN_HEIGHT - GROUND_HEIGHT,
             SCREEN_WIDTH, GROUND_HEIGHT)
        )

        # Draw player
        pygame.draw.rect(screen, RED, player_rect)

        # Draw obstacles
        for obstacle in obstacles:
            obstacle.draw(screen)

        # Draw score
        score_text = font.render(
            f"Score: {int(score)}",
            True,
            BLACK
        )

        screen.blit(score_text, (10, 10))

    else:

        # Game Over screen
        screen.fill(WHITE)

        game_over_text = game_over_font.render(
            "GAME OVER",
            True,
            BLACK
        )

        game_over_rect = game_over_text.get_rect(
            center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 30)
        )

        screen.blit(game_over_text, game_over_rect)

        final_score_text = font.render(
            f"Final Score: {int(score)}",
            True,
            BLACK
        )

        final_score_rect = final_score_text.get_rect(
            center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 20)
        )

        screen.blit(final_score_text, final_score_rect)

        restart_text = font.render(
            "Press SPACE to Restart",
            True,
            BLACK
        )

        restart_rect = restart_text.get_rect(
            center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 60)
        )

        screen.blit(restart_text, restart_rect)

    # Update display
    pygame.display.flip()

    # FPS
    clock.tick(60)

pygame.quit()
